import { Routes, Route, Navigate } from "react-router-dom";

import { PromotionList } from "../component/promotions/PromotionList";
import { PromotionCreate } from "../component/promotions/PromotionCreate";
import { PromotionDetail } from "../component/promotions/PromotionDetail";

export default function AppRoutes() {
    return (
        <Routes>
            <Route
                path="/"
                element={<Navigate to="/admin/promotions" replace />}
            />

            <Route
                path="/admin/promotions"
                element={<PromotionList />}
            />

            <Route
                path="/admin/promotions/create"
                element={<PromotionCreate />}
            />

            <Route
                path="/admin/promotions/:id"
                element={<PromotionDetail />}
            />
        </Routes>
    );
}