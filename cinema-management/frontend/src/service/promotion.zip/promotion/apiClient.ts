export const API_URL =
  import.meta.env.VITE_API_URL ??
  'http://localhost:8080'

export interface ApiErrorData {
  message?: string
  errors?: Record<string, string>
}

export class ApiError extends Error {
  status: number
  errors: Record<string, string>

  constructor(
    message: string,
    status: number,
    errors: Record<string, string> = {}
  ) {
    super(message)

    this.name = 'ApiError'
    this.status = status
    this.errors = errors
  }
}

async function parseResponse<T>(response: Response): Promise<T> {
  const text = await response.text()

  let data: unknown = null

  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      data = text
    }
  }

  if (!response.ok) {
    const errorData =
      typeof data === 'object' && data !== null
        ? (data as ApiErrorData)
        : {}

    throw new ApiError(
      errorData.message ?? 'Có lỗi xảy ra',
      response.status,
      errorData.errors ?? {}
    )
  }

  return data as T
}

export async function apiRequest<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, options)

  return parseResponse<T>(response)
}